from django.db import models

# Create your models here.

class Remainder(models.Model):
    CHOICES = (("Bengali", 'Bengali'),
                       ("Hindi", 'Hindi'),
                       ("English", 'English'),
                       ("History", 'History'),
                       ("Geography", 'Geography'),
                       ("Life Science", 'Life Science'),
                       )
    date = models.DateField(auto_now_add=True,blank=False)
    subject = models.CharField(blank=False,choices=CHOICES,max_length=50)
    add_description = models.TextField(blank=False)
    email = models.EmailField(blank=False,unique=True)
    sms = models.CharField(max_length=200)
    contact = models.CharField(max_length=10,unique=True)
    recur_for_next = models.CharField(max_length=20)
    username = models.CharField(blank=False,max_length=200)
    userid =models.DecimalField(decimal_places=0, max_digits=10)

    def __str__(self):
        return self.username



